package calculator;

public class MyCalculator {
    private Double num1 = null;
    private Double num2 = null;
    private ICalculatorOperation operation = null;
    private boolean debugMode = false;
    
    public MyCalculator() {
        
    }
    
    public void setDebugMode(boolean bool) {
        debugMode = bool;
    }
    
    public void setFirstOperand(double num) {
        num1 = num;
        
        if (debugMode) {
            System.out.println("Num 1: " + num);
        }
    }
    
    public void setSecondOperand(double num) {
        num2 = num;
        
        if (debugMode) {
            System.out.println("Num 2: " + num);
        }
    }
    
    public double getFirstOperand() {
        return num1;
    }
    
    public double getSecondOperand() {
        return num2;
    }
    
    public ICalculatorOperation getOperation() {
        return operation;
    }
    
    public boolean hasFirstOperand() {
        return (num1 != null);
    }
    
    public boolean hasOperation() {
        return (operation != null);
    }
    
    public boolean hasSecondOperand() {
        return (num2 != null);
    }
    
    public void setOperation(ICalculatorOperation op) {
        operation = op;
        num2 = null;
        
        if (debugMode) {
            System.out.println("Operation: " + op.getSymbol());
        }
    }
    
    public double performOperation() throws CalcException {
        try {
            if (!hasFirstOperand() || !hasSecondOperand())
                throw new MissingOperandException();
            
            if (!hasOperation())
                throw new MissingOperationException();
            
            double result = operation.operate(num1, num2);
            num1 = result;
            
            if (debugMode) {
                System.out.println("Result: " + result);
            }
            
            return result;
        }
        catch (CalcException ex) {
            clear();
            
            if (debugMode) {
                System.out.println(ex.getMessage());
            }
            throw ex;
        }
    }
    
    public void clear() {
        num1 = null;
        num2 = null;
        operation = null;
    }
}