package calculator;

public interface ICalculatorOperation {
        double operate(double a, double b) throws CalcOperationException;
        String getSymbol();
}
