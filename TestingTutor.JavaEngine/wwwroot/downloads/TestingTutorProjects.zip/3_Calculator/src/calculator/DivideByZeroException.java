package calculator;

public class DivideByZeroException extends CalcOperationException {

    public DivideByZeroException() {
        super("Division operation failed: cannot divide by zero.");
    }
}
