package calculator;

public class MissingOperationException extends CalcException {

    public MissingOperationException() {
        super("Calculation failed: missing an operation.");
    }
}
