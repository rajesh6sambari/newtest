package calculator;

public class CalcOperationException extends CalcException {
    public CalcOperationException() {
        super();
    }
    public CalcOperationException(String message) {
        super(message);
    }
}
