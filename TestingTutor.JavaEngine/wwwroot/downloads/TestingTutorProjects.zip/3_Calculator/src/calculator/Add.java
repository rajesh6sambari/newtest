package calculator;

public class Add implements ICalculatorOperation {

    @Override
    public double operate(double a, double b) {
        return a + b;
    }
    
    @Override
    public String getSymbol() {
        return "+";
    }
}