package calculator;

public class MissingOperandException extends CalcException {

    public MissingOperandException() {
        super("Calculation failed: missing an operand.");
    }
}
