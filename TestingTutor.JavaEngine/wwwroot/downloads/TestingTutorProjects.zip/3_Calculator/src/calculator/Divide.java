package calculator;

public class Divide implements ICalculatorOperation  {

    @Override
    public double operate(double a, double b) throws DivideByZeroException {
        if (b == 0)
            throw new DivideByZeroException();
        return a / b;
    }
    
    @Override
    public String getSymbol() {
        return "/";
    }
}
