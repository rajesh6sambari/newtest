package calculator;

import org.junit.Test;
import static org.junit.Assert.*;

public class MyCalculatorTest {
    
    /**
     * This test demonstrates the use of MyCalculator
     * and how you might go about testing the expected
     * behavior of MyCalculator for the multiply operation.
     */
    @Test
    public void multiply_MultlyingThreeTimesFourShouldResultInTwelve()
    {
        // ARRANGE
        MyCalculator myCalculator = new MyCalculator();
        myCalculator.setFirstOperand(3.0);
        myCalculator.setOperation(new Multiply());
        myCalculator.setSecondOperand(4.0);
        
        double expected = 3.0 * 4.0;
        
        // ACT
        double actual = 0.0;
        
        try {
            actual = myCalculator.performOperation();
        } catch (CalcException ex) {
            fail("Unexpected exception");
        }
        
        // ASSERT
        assertEquals(expected, actual, 0.0);
    }
    
}
