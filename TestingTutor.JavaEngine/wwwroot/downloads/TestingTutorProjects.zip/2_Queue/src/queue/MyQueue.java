package queue;

public class MyQueue<T>
{
   private final int DEFAULT_CAPACITY = 100;
   private int front, rear, count;
   private T[] queue; 

   public MyQueue ()
   {
      front = rear = count = 0;
      queue = (T[]) (new Object[DEFAULT_CAPACITY]);
   }

   public MyQueue (int initialCapacity)
   {
      front = rear = count = 0;
      queue = ( (T[])(new Object[initialCapacity]) );
   }

   public void enqueue (T element)
   {
      if (size() == queue.length) 
         throw new IllegalStateException("Queue is full");

      queue[rear] = element;

      rear = (rear+1) % queue.length;

      count++;
   }

   public T dequeue() throws IllegalStateException
   {
      if (isEmpty())
         throw new IllegalStateException ("Queue is empty");

      T result = queue[front];
      queue[front] = null;

      front = (front+1) % queue.length;

      count--;

      return result;
   }
   
   public T first() throws IllegalStateException
   {
      if (isEmpty())
         throw new IllegalStateException ("Queue is empty"); 

      return queue[front];
   }
   
   public T last() throws IllegalStateException
   {
      if (isEmpty())
         throw new IllegalStateException ("Queue is empty"); 

      return queue[rear - 1];
   }

   public boolean isEmpty() {
      return count == 0;
   }
 

   public int size() {
      return count;
   }

}
