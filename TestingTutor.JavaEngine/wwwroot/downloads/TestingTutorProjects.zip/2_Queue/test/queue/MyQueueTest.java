package queue;

import org.junit.Test;
import static org.junit.Assert.*;

public class MyQueueTest {
        
    /**
     * This test demonstrates the use of MyQueue
     * and how you might go about testing the expected
     * behavior of the an empty queue.
     */
    @Test
    public void size_shouldBeZeroForEmptyQueue()
    {
        // ARRANGE
        // Class under test and expected
        var myQueue = new MyQueue<Integer>();
        var expectedSize = 0;
        
        // ACT
        var actualSize = myQueue.size();
        
        // ASSERT
        assertEquals(expectedSize, actualSize);
          
    }

}
