package mydate;

import static org.junit.Assert.assertTrue;
import org.junit.Test;

public class MyDateTest {
    /**
     * This example test demonstrates the use of MyDate
     * and how you might go about testing it.
     */
    @Test
    public void isAfter_ShouldReturnTrueForIndependenceDayBeingBeforeYearY2K() {
        // Arrange
        var independenceDay = new MyDate(7, 4, 1776);
        var y2K = new MyDate(1, 1, 2000);
       
        // Act
        boolean y2KIsAfterIndependenceDay = y2K.isAfter(independenceDay);
        
        // Assert
        assertTrue(y2KIsAfterIndependenceDay);
    }
    
    
}
