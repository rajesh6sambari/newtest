package csvparser;

import java.util.List;
import org.junit.Test;
import static org.junit.Assert.*;

public class MyCsvParserTest {
    
    /**
     * This test demonstrates the use of MyCsvParser
     * and how you might go about testing the expected
     * behavior.
     */
    @Test
    public void getColumnNames_DataShouldHaveThreeColumns()
    {
        // ARRANGE
        String data = "FirstName;MiddleInitial;LastName" + System.lineSeparator() +
                "jake,r,zenger" + System.lineSeparator() +
                "lucas,p,cordova" + System.lineSeparator() +
                "john,c,smith" + System.lineSeparator() +
                "phong,l,nguyen";
            
        List<Record> records = null;
        MyCsvParser parser = new MyCsvParser(data);
        int numberOfColumns = 0;
        
        // ACT
        try {
            records = parser.parse();   
            numberOfColumns = parser.getColumnNames().length;
            // ASSERT
        } catch (Exception ex) {
            fail("Unexpected parser exception\n" + ex.toString());
        }
        
        // ASSERT
        assertEquals(3, numberOfColumns);
    }
    
}
