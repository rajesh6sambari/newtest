package csvparser;

import java.util.ArrayList;
import java.util.List;


public class Record {
    final private List<DataField> fields;
    
    public Record() {
        fields = new ArrayList<>();
    }
    
    public void addField(String columnName, String value) {
        fields.add(new DataField(columnName, value));
    }
    
    public List<DataField> getDataFields() {
        return fields;
    }
    
    public Integer fieldCount() {
        return fields.size();
    }
}
