package csvparser;

public class DataField {
    final private String column;
    final private String value;
    
    public DataField(String column, String value) {
        this.column = column;
        this.value = value;
    }
    
    public String getColumn() {
        return column;
    }
    
    public String getValue() {
        return value;
    }
}
