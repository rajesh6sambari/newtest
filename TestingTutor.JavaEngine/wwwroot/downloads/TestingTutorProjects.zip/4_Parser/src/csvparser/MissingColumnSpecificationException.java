package csvparser;

public class MissingColumnSpecificationException extends Exception {
    public MissingColumnSpecificationException(String message) {
        super(message);
    }
}