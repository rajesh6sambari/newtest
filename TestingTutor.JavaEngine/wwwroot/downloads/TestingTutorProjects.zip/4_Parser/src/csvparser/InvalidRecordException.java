package csvparser;

public class InvalidRecordException extends Exception {
    public InvalidRecordException() {
        super();
    }
    public InvalidRecordException(String message) {
        super(message);
    }
}
