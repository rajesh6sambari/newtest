package csvparser;

import java.io.BufferedReader;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

public class MyCsvParser {
    
    final private String data;
    
    public MyCsvParser(String data) {
        this.data = data;
    }
    
    public List<Record> parse() throws Exception {
        List<Record> records = new ArrayList<>();
        BufferedReader reader = new BufferedReader(new StringReader(data));  
        
        String[] columnNames = getColumnNames();
        
        String dataLine = reader.readLine();
        int lineNum = 2;
        while ((dataLine = reader.readLine()) != null) {
            Record record = new Record();
            String[] values = dataLine.split("(?<!\\\\),");
            
            if (values.length != columnNames.length) {
                // throw an error. This record does not meet the column specifications for this CSV file.
                throw new InvalidRecordException("Record at line " + lineNum + " does not meet the column specifications for this CSV file.");
            }
            
            // add each value in this line to the record
            for (int i = 0; i < values.length; i++) {
                record.addField(columnNames[i % columnNames.length],values[i].trim());
            }
            
            records.add(record);
            lineNum++;
        }
        
        return records;
    }
    
    public String[] getColumnNames() throws Exception {
        BufferedReader reader = new BufferedReader(new StringReader(data));  
        String columnSpecLine = reader.readLine();
        String[] columns = columnSpecLine.split(";");
        
        if (columns.length <= 1) {
            // throw an error. File does not begin with a properly formatted column specification line.
            throw new MissingColumnSpecificationException("File does not begin with a properly formatted column specification line. The first line must specify column names in order, each delimited by a semicolon.");
        }
        
        return columns;
    }
}
